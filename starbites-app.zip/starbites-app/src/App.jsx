import StarBitesGame from './StarBitesGame'

function App() {
  return <StarBitesGame />
}

export default App
